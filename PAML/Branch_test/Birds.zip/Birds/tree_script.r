library(ape)
a<-read.tree("birds_functional.nwk")
b<-unroot(a)
write.tree(b,"birds_functional.nwk.tree")
