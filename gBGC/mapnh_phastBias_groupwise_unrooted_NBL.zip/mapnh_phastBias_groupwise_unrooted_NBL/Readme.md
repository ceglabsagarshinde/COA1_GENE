
# mapnh and phastBias groupwise

In groupwise combinations, mapnh was used to calculate GC*, while HYPHYMP and PAML were used for dN/dS calculation. Each group folder have their respective tree file (.nwk), aligned fasta file (.aln), PAML control file (codeml1), Hyphy control and config files (dNdS.bf, and newconf),and code file (script.sh).
Similarly phastBias was used to calculate gBGC. Required script is provided in each folder(phast.sh).

