## Gene loss Feliformia

This folder contains input and output files for Feliformia as foreground (non-functional gene species) under branch free model using PAML 4.9f. The control file requires an alignment file and a newick tree (labelled). The results of this study are provided in outfilecompile file.  Script is provided in the folder (Feliformia_wrapper.sh) 
