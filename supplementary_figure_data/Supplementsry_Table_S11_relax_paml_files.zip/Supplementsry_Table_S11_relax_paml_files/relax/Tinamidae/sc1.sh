i=$1

#Run multiple MSA programs through guidance with 100 bootstraps
perl /home/ceglab6/guidance.v2.02/www/Guidance/guidance.pl --program GUIDANCE --seqFile "$i" --msaProgram PRANK --seqType codon --outDir "$i".100_PRANK --genCode 1 --bootstraps 100 --proc_num 4
#sort MSA files before comparing
##Use https://github.com/shenwei356/seqkit
seqkit sort "$i".100_PRANK/MSA.PRANK.aln.With_Names >"$i".100_PRANK/"$i".PRANK.aln
cd "$i".100_PRANK
modeltest-ng -i "$i".PRANK.aln -t ml -T raxml

for j in "$i".PRANK 
do
BICmodel=`grep -A 2 "Best model according to BIC" "$j".aln.out|tail -1|awk '{print $2}'`
AICmodel=`grep -A 2 "Best model according to AICc" "$j".aln.out|tail -1|awk '{print $2}'`
echo $j $BICmodel $AICmodel
done

j="$i".PRANK
model=`grep -A 2 "Best model according to BIC" "$j".aln.out|tail -1|awk '{print $2}'`
#Using the PRANK alignment best model according to BIC
echo "Model $model has been selected." >> "$i".log

raxml-ng --all -msa "$i".PRANK.aln --model $model --bs-trees 1000 --threads 2
cp "$i".PRANK.aln "$i".PRANK.aln.raxml.bestTree ../
