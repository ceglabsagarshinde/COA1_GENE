library(ape)
a<-read.tree("Strigops_habroptila_COA1.nwk")
b<-unroot(a)
write.tree(b,"Strigops_habroptila_COA1.nwk.tree")
