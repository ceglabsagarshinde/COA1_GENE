library(ape)
a<-read.tree("Strigops_habroptila.nwk")
b<-unroot(a)
write.tree(b,"Strigops_habroptila.nwk.tree")
