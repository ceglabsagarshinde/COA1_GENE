library(ape)
a<-read.tree("Alectoris_rufa.nwk")
b<-unroot(a)
write.tree(b,"Alectoris_rufa.nwk.tree")
