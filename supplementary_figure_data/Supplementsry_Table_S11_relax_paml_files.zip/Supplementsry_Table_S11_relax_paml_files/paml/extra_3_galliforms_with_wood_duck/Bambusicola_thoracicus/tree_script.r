library(ape)
a<-read.tree("Bambusicola_thoracicus.nwk")
b<-unroot(a)
write.tree(b,"Bambusicola_thoracicus.nwk.tree")
