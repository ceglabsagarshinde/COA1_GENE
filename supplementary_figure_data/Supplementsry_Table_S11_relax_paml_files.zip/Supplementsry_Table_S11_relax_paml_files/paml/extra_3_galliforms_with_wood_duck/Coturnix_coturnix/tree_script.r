library(ape)
a<-read.tree("Coturnix_coturnix.nwk")
b<-unroot(a)
write.tree(b,"Coturnix_coturnix.nwk.tree")
