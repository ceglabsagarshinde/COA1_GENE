library(ape)
a<-read.tree("Cuculiformes_COA1.nwk")
b<-unroot(a)
write.tree(b,"Cuculiformes_COA1.nwk.tree")
