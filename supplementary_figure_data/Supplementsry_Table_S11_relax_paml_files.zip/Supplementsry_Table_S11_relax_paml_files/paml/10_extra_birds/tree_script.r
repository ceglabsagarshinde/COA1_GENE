library(ape)
a<-read.tree("10_birds.nwk")
b<-unroot(a)
write.tree(b,"10_birds.nwk.tree")
