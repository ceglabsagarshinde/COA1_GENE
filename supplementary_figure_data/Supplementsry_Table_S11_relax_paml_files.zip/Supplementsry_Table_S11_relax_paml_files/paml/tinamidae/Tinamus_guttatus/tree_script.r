library(ape)
a<-read.tree("Tinamus_guttatus.nwk")
b<-unroot(a)
write.tree(b,"Tinamus_guttatus.nwk.tree")
