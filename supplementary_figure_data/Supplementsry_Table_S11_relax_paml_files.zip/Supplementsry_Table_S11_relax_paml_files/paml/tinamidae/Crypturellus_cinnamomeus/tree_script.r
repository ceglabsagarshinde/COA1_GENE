library(ape)
a<-read.tree("Crypturellus_cinnamomeus.nwk")
b<-unroot(a)
write.tree(b,"Crypturellus_cinnamomeus.nwk.tree")
