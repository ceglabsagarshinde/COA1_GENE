library(ape)
a<-read.tree("Nothoprocta_ornata.nwk")
b<-unroot(a)
write.tree(b,"Nothoprocta_ornata.nwk.tree")
