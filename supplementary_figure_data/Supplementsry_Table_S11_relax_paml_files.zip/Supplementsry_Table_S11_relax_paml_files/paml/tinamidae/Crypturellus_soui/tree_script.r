library(ape)
a<-read.tree("Crypturellus_soui.nwk")
b<-unroot(a)
write.tree(b,"Crypturellus_soui.nwk.tree")
