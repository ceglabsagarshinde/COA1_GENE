library(ape)
a<-read.tree("Nothoprocta_perdicaria.nwk")
b<-unroot(a)
write.tree(b,"Nothoprocta_perdicaria.nwk.tree")
