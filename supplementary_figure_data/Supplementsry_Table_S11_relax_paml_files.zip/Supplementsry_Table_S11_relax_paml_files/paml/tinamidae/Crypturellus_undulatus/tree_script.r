library(ape)
a<-read.tree("Crypturellus_undulatus.nwk")
b<-unroot(a)
write.tree(b,"Crypturellus_undulatus.nwk.tree")
