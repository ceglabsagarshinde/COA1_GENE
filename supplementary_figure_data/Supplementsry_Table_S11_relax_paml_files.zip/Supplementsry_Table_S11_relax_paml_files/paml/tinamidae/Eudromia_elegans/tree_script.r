library(ape)
a<-read.tree("Eudromia_elegans.nwk")
b<-unroot(a)
write.tree(b,"Eudromia_elegans.nwk.tree")
