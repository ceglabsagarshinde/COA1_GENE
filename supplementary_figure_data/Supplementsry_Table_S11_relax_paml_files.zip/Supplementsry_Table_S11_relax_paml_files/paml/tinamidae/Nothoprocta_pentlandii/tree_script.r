library(ape)
a<-read.tree("Nothoprocta_pentlandii.nwk")
b<-unroot(a)
write.tree(b,"Nothoprocta_pentlandii.nwk.tree")
