library(ape)
a<-read.tree("Nothocercus_nigrocapillus.nwk")
b<-unroot(a)
write.tree(b,"Nothocercus_nigrocapillus.nwk.tree")
