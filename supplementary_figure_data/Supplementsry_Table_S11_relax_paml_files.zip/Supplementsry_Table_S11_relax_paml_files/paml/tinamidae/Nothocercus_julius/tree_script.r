library(ape)
a<-read.tree("Nothocercus_julius.nwk")
b<-unroot(a)
write.tree(b,"Nothocercus_julius.nwk.tree")
