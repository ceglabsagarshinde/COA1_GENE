library(ape)
a<-read.tree("Phalacrocorax_auritus_coa1.nwk")
b<-unroot(a)
write.tree(b,"Phalacrocorax_auritus_coa1.nwk.tree")
