library(ape)
a<-read.tree("Phalacrocorax_pelagicus_coa1.nwk")
b<-unroot(a)
write.tree(b,"Phalacrocorax_pelagicus_coa1.nwk.tree")
