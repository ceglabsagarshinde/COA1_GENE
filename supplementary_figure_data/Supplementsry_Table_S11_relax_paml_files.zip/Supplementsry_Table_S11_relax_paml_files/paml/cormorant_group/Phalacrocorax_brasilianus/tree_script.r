library(ape)
a<-read.tree("Phalacrocorax_brasilianus_coa1.nwk")
b<-unroot(a)
write.tree(b,"Phalacrocorax_brasilianus_coa1.nwk.tree")
